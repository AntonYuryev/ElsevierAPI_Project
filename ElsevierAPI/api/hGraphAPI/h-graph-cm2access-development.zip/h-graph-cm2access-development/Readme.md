Lightly modified from, and intended to replace CM2Access.py in `https://gitlab.et-scm.com/candi-coca/PointOfCarePy/blob/master/PointOfCare/NLP/CM2Access.py`

Intended use:

```
pip install <directory path to cm2access repo>
```
Then, in code,
```
import cm2access  # pip install cm2access from https://gitlab.et-scm.com/DOWLINGW/cm2access
...
annotation_list = cm2access.annotateString(string_to_annotate)
```
